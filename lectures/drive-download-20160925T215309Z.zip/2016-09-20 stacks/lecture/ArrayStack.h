#ifndef ARRAY_STACK_H
#define ARRAY_STACK_H

template <typename T>
class ArrayStack
{
private:
    T *_data = nullptr;
    int _logical_size = 0;
    int _physical_size = 0;

public:
    ArrayStack(int stack_size = 10)
    {
        //dynamically allocate an array of size stack_size
        _data = new T[stack_size];
        _physical_size = stack_size;
    }

    //Adds a new item onto our stack
    void push(T value)
    {
        //1 , 2 , 3 , 4
        //  , 1 , 2 , 3 , 4
        //7
        for(int i = _logical_size; i > -1; i--)
        {
            _data[i + 1] = _data[i];
        }
        _data[0] = value;
        _logical_size++;
    }

    //removes an item from the stack
    T pop()
    {
		T item = _data[0];
		for(int i = 0; i < _logical_size; i++)
        {
            _data[i] = _data[i + 1];
        }
        _logical_size--;
        return item;
    }

    //returns size of stack
    int getSize()
    {
        return _logical_size;
    }

    //returns whether or not stack is empty
    bool isEmpty()
    {
        return _logical_size == 0;
    }
};

#endif // STACK_H


