#include <iostream>
#include <string>
#include <vector>
#include "ArrayStack.h"
#include "ArrayStackV2.h"

using namespace std;

int main()
{
    ArrayStackV2<char> test_stack{100};
    string test = "This is a test";
    for(char ch : test)
    {
        test_stack.push(ch);
    }
    while(test_stack.isEmpty() == false)
    {
        cout << test_stack.pop() << endl;
    }
    return 0;
}
