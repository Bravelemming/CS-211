#ifndef ARRAY_STACK_V2_H
#define ARRAY_STACK_V2_H

template <typename T>
class ArrayStackV2
{
private:
    T *_data = nullptr;
    int _logical_size = 0;
    int _physical_size = 0;

public:
    ArrayStackV2(int stack_size = 10)
    {
        //dynamically allocate an array of size stack_size
        _data = new T[stack_size];
        _physical_size = stack_size;
    }

    //Adds a new item onto our stack
    void push(T value)
    {
        _data[_logical_size] = value;
        _logical_size++;
    }

    //removes an item from the stack
    T pop()
    {
        _logical_size--;
		T item = _data[_logical_size];
        return item;
    }

    //returns size of stack
    int getSize()
    {
        return _logical_size;
    }

    //returns whether or not stack is empty
    bool isEmpty()
    {
        return _logical_size == 0;
    }
};

#endif // STACK_H



