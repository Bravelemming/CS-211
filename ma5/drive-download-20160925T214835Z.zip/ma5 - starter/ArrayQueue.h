#ifndef ARRAY_QUEUE_H
#define ARRAY_QUEUE_H

template <typename T>
class ArrayQueue
{
private:
    T *_data = nullptr;
    int _logical_size = 0;
    int _physical_size = 0;

public:
    ArrayQueue(int size = 10)
    {
        _physical_size = size;
        _data = new T[_physical_size];
    }

    //destructors are responsible for deleting dynamically created
    //memory
    ~ArrayQueue()
    {
        delete[] _data;
    }

    void enqueue(T item)
    {
        _data[_logical_size] = item;
        _logical_size++;
    }

    //MA5 TODO: complete!
    T dequeue()
    {
        return "";
    }

    int getSize()
    {
        return _logical_size;
    }
};

#endif // ARRAY_QUEUE_H
