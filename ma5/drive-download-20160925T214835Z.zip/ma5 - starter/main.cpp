#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include "StringSplitter.h"
#include "ArrayQueue.h"
#include "ListQueue.h"

using namespace std;

void stringSplitTest()
{
    string test = "This is a test";
    queue<string> result = StringSplitter::splitQ(test, " ");
    while(result.size() > 0)
    {
        cout << result.front() << endl;
        result.pop();

    }
}

void arrayQueueTest()
{
    ArrayQueue<string> q{};
    q.enqueue("a");
    cout << q.dequeue() << endl;;
    q.enqueue("b");
    q.enqueue("c");
    q.enqueue("d");
    while(q.getSize() > 0)
    {
        cout << q.dequeue() << endl;
    }
}

void listQueueTest()
{
    ListQueue<string> q{};
    q.enqueue("a");
    cout << q.dequeue() << endl;;
    q.enqueue("b");
    q.enqueue("c");
    q.enqueue("d");
    while(q.getSize() > 0)
    {
        cout << q.dequeue() << endl;
    }
}

int main()
{
    arrayQueueTest();
    //listQueueTest();
    return 0;
}
