#ifndef LIST_QUEUE_H
#define LIST_QUEUE_H

#include "LinkedListNode.h"

template <typename T>
class ListQueue
{
private:
    LinkedListNode<T> *_front = nullptr;
    LinkedListNode<T> *_back = nullptr;
    int _size = 0;

public:
    ListQueue()
    {

    }

    //always remember to clean up dynamic memory
    ~ListQueue()
    {
        LinkedListNode<T> *current = _front;
        while(current != nullptr)
        {
            LinkedListNode<T> *next = current->getNext();
            delete current;
            current = next;
        }
    }

    void enqueue(T data)
    {
        switch(_size)
        {

            //size 0?
        case 0:
            _front = new LinkedListNode<T>{data};
            _back = _front;
            break;

            //size 1?
        case 1:
            _back = new LinkedListNode<T>{data};
            _front->setNext(_back);
            break;

            //everything else?
        default:
            LinkedListNode<T> *next = new LinkedListNode<T>{data};
            _back->setNext(next);
            _back = next;
            break;
        }

        //make sure to up our internal size
        _size++;
    }

    T dequeue()
    {
        T result;

        //Assumption: size is greater than 0
        result = _front->getValue();

        LinkedListNode<T> *new_front = nullptr;
        if(_size > 1)
        {
            new_front = _front->getNext();
        }
        delete _front;
        _front = new_front;
        if(_size == 1)
        {
            _back = _front;
        }
        _size--;
        return result;
    }

    int getSize()
    {
        return _size;
    }
};

#endif // LIST_QUEUE_H
